Els fitxer modificats s�n:

* sensor.c
* hal_msp430FET.h , la funcio PORT_INIT()