/*
 * blink.h
 *
 *  Created on: 17/04/2013
 *      Author: Manel
 */

#ifndef BLINK_H_
#define BLINK_H_

void InitP2_7(void);


#endif /* BLINK_H_ */
